using UnityEngine;

public class PosteLight : MonoBehaviour
{
    [Header("Configuração")]
    public float radius = 6f;
    public int vidaMaxima = 2;
    public int vidaAtual;

    private CircleCollider2D lightCollider;
    private LightSource lightSource;

    void Awake()
    {
        vidaAtual = vidaMaxima;

        lightCollider = GetComponent<CircleCollider2D>();
        if (lightCollider == null)
            lightCollider = gameObject.AddComponent<CircleCollider2D>();

        lightCollider.radius = radius;
        lightCollider.isTrigger = true;
        gameObject.tag = "IlluminatedZone";
        gameObject.layer = LayerMask.NameToLayer("LuzLayer");

        lightSource = GetComponent<LightSource>();
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        foreach (var enemy in FindObjectsByType<EnemyAI>(FindObjectsSortMode.None))
            enemy.SetPlayerIlluminated(true);
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (!other.CompareTag("Player")) return;
        foreach (var enemy in FindObjectsByType<EnemyAI>(FindObjectsSortMode.None))
            enemy.SetPlayerIlluminated(false);
    }

    public void BreakLight()
    {
        vidaAtual--;
        if (vidaAtual > 0) return;

        foreach (var enemy in FindObjectsByType<EnemyAI>(FindObjectsSortMode.None))
            enemy.SetPlayerIlluminated(false);

        LightManager.Instance?.RegistrarLuzApagada();

        if (lightSource != null)
            lightSource.BreakLight();

        lightCollider.enabled = false;

        // desativa o sprite para o poste sumir visualmente
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null) sr.enabled = false;
    }

    public void ReativarLuz()
    {
        vidaAtual = vidaMaxima;
        lightCollider.enabled = true;

        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null) sr.enabled = true;
    }
}